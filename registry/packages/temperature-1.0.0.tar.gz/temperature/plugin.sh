#!/bin/bash
case "$1" in
    "check") exit 0 ;;
    "collect")
        echo "PANE:Thermal Sensors"
        i=0
        for zone in /sys/class/thermal/thermal_zone*/temp; do
            if [ -f "$zone" ]; then
                raw=$(cat "$zone" 2>/dev/null)
                if [ -n "$raw" ] && [ "$raw" -gt 0 ] 2>/dev/null; then
                    celsius=$((raw / 1000))
                    type_file="$(dirname $zone)/type"
                    type_name="zone$i"
                    [ -f "$type_file" ] && type_name=$(cat "$type_file" 2>/dev/null)
                    echo "sensor.${type_name}=${celsius}:GAUGE:°C"
                fi
            fi
            i=$((i+1))
        done
        # CPU freq if available
        if [ -f /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq ]; then
            freq=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq)
            freq_mhz=$((freq / 1000))
            echo "cpu.frequency=${freq_mhz}:GAUGE:MHz"
        fi
        # Fan speed if available
        for fan in /sys/class/hwmon/hwmon*/fan1_input; do
            if [ -f "$fan" ]; then
                rpm=$(cat "$fan" 2>/dev/null)
                echo "fan.speed=${rpm}:GAUGE:RPM"
                break
            fi
        done
        echo "ENDPANE"
        ;;
esac
