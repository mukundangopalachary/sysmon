#!/bin/bash
if [ "$1" == "collect" ]; then
    echo "PANE:Thermals"
    echo "cpu.temp=$(( (RANDOM % 15) + 45 )):GAUGE:C"
    echo "sys.temp=$(( (RANDOM % 10) + 40 )):GAUGE:C"
    echo "ENDPANE"
fi
