#!/bin/bash
case "$1" in
    "check") exit 0 ;;
    "collect")
        echo "PANE:Network Health"
        # Ping Google DNS
        ping_out=$(ping -c 1 -W 2 8.8.8.8 2>/dev/null)
        if [ $? -eq 0 ]; then
            latency=$(echo "$ping_out" | grep 'time=' | sed 's/.*time=\([0-9.]*\).*/\1/')
            echo "ping.google_dns=${latency}:GAUGE:ms"
            echo "connectivity=1:GAUGE:up"
        else
            echo "ping.google_dns=timeout:GAUGE:"
            echo "connectivity=0:GAUGE:down"
        fi
        # DNS resolution time
        dns_start=$(date +%s%N)
        nslookup google.com > /dev/null 2>&1
        dns_end=$(date +%s%N)
        dns_ms=$(( (dns_end - dns_start) / 1000000 ))
        echo "dns.resolve_time=${dns_ms}:GAUGE:ms"
        # Active connections count
        if [ -f /proc/net/tcp ]; then
            established=$(grep ' 01 ' /proc/net/tcp 2>/dev/null | wc -l)
            echo "tcp.established=${established}:GAUGE:conns"
        fi
        # Default gateway
        gw=$(ip route 2>/dev/null | grep default | awk '{print $3}' | head -1)
        if [ -n "$gw" ]; then
            gw_ping=$(ping -c 1 -W 1 "$gw" 2>/dev/null | grep 'time=' | sed 's/.*time=\([0-9.]*\).*/\1/')
            [ -n "$gw_ping" ] && echo "ping.gateway=${gw_ping}:GAUGE:ms"
        fi
        echo "ENDPANE"
        ;;
esac
