#!/bin/bash
if [ "$1" == "collect" ]; then
    echo "PANE:Ping"
    echo "latency.google=$(( (RANDOM % 10) + 15 )):GAUGE:ms"
    echo "packet.loss=0:GAUGE:%"
    echo "ENDPANE"
fi
