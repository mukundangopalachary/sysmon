#!/bin/bash
case "$1" in
    "check") which docker > /dev/null 2>&1 && exit 0 || exit 0 ;;
    "collect")
        echo "PANE:Docker Engine"
        if ! which docker > /dev/null 2>&1; then
             echo "error=Docker not installed:TEXT:"
             echo "ENDPANE"
             exit 0
        fi
        
        # Check permissions
        docker info > /dev/null 2>&1
        if [ $? -ne 0 ]; then
             echo "error=Permission denied:TEXT:"
             echo "fix=Add user to docker group:TEXT:"
             echo "ENDPANE"
             exit 0
        fi

        running=$(docker ps -q 2>/dev/null | wc -l)
        stopped=$(docker ps -aq --filter "status=exited" 2>/dev/null | wc -l)
        total_images=$(docker images -q 2>/dev/null | wc -l)
        volumes=$(docker volume ls -q 2>/dev/null | wc -l)
        networks=$(docker network ls -q 2>/dev/null | wc -l)
        # Disk usage
        du_info=$(docker system df --format '{{.Size}}' 2>/dev/null | head -1)
        echo "containers.running=${running}:GAUGE:active"
        echo "containers.stopped=${stopped}:GAUGE:exited"
        echo "images.total=${total_images}:GAUGE:images"
        echo "volumes.count=${volumes}:GAUGE:vols"
        echo "networks.count=${networks}:GAUGE:nets"
        [ -n "$du_info" ] && echo "disk.usage=${du_info}:GAUGE:"
        echo "ENDPANE"
        ;;
esac
