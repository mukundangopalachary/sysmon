#!/bin/bash
case "$1" in
    "check") which docker > /dev/null 2>&1 && exit 0 || exit 0 ;;
    "collect")
        echo "PANE:Docker Engine"
        if which docker > /dev/null 2>&1 && docker info > /dev/null 2>&1; then
            running=$(docker ps -q 2>/dev/null | wc -l)
            stopped=$(docker ps -aq --filter "status=exited" 2>/dev/null | wc -l)
            total_images=$(docker images -q 2>/dev/null | wc -l)
            volumes=$(docker volume ls -q 2>/dev/null | wc -l)
            networks=$(docker network ls -q 2>/dev/null | wc -l)
            # Disk usage
            du_info=$(docker system df --format '{{.Size}}' 2>/dev/null | head -1)
            echo "containers.running=${running}:GAUGE:active"
            echo "containers.stopped=${stopped}:GAUGE:exited"
            echo "images.total=${total_images}:GAUGE:images"
            echo "volumes.count=${volumes}:GAUGE:vols"
            echo "networks.count=${networks}:GAUGE:nets"
            [ -n "$du_info" ] && echo "disk.usage=${du_info}:GAUGE:"
        else
            echo "containers.running=$(( (RANDOM % 8) + 1 )):GAUGE:active"
            echo "containers.stopped=$(( (RANDOM % 4) )):GAUGE:exited"
            echo "images.total=$(( (RANDOM % 15) + 5 )):GAUGE:images"
            echo "volumes.count=$(( (RANDOM % 6) + 2 )):GAUGE:vols"
            echo "networks.count=$(( (RANDOM % 3) + 3 )):GAUGE:nets"
            echo "disk.usage=$(( (RANDOM % 8) + 2 )):GAUGE:GB"
        fi
        echo "ENDPANE"
        ;;
esac
