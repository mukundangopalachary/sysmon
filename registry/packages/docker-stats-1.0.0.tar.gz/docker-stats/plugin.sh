#!/bin/bash
if [ "$1" == "collect" ]; then
    echo "PANE:Docker"
    echo "containers.running=$(( (RANDOM % 5) + 1 )):GAUGE:count"
    echo "containers.stopped=$(( (RANDOM % 3) )):GAUGE:count"
    echo "ENDPANE"
fi
