#!/bin/bash
case "$1" in
    "check") which nvidia-smi > /dev/null 2>&1 && exit 0 || exit 0 ;;
    "collect")
        if which nvidia-smi > /dev/null 2>&1; then
            data=$(nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,fan.speed,clocks.gr --format=csv,noheader,nounits 2>/dev/null)
            IFS=',' read -r gpu_util mem_used mem_total temp power fan clock <<< "$data"
            echo "PANE:GPU Status"
            echo "gpu.utilization=$(echo $gpu_util | tr -d ' '):GAUGE:%"
            echo "memory.used=$(echo $mem_used | tr -d ' '):GAUGE:MB"
            echo "memory.total=$(echo $mem_total | tr -d ' '):GAUGE:MB"
            echo "gpu.temperature=$(echo $temp | tr -d ' '):GAUGE:°C"
            echo "power.draw=$(echo $power | tr -d ' '):GAUGE:W"
            echo "fan.speed=$(echo $fan | tr -d ' '):GAUGE:%"
            echo "clock.speed=$(echo $clock | tr -d ' '):GAUGE:MHz"
            echo "ENDPANE"
        else
            echo "PANE:GPU Status (Simulated)"
            echo "gpu.utilization=$(( (RANDOM % 60) + 10 )):GAUGE:%"
            echo "memory.used=$(( (RANDOM % 2000) + 1000 )):GAUGE:MB"
            echo "memory.total=8192:GAUGE:MB"
            echo "gpu.temperature=$(( (RANDOM % 20) + 45 )):GAUGE:°C"
            echo "power.draw=$(( (RANDOM % 80) + 50 )):GAUGE:W"
            echo "fan.speed=$(( (RANDOM % 40) + 30 )):GAUGE:%"
            echo "clock.speed=$(( (RANDOM % 500) + 1200 )):GAUGE:MHz"
            echo "ENDPANE"
        fi
        ;;
esac
