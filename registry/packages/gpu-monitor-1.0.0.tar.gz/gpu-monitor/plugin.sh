#!/bin/bash
if [ "$1" == "collect" ]; then
    echo "PANE:Nvidia GPU"
    echo "gpu.load=$(( (RANDOM % 30) + 20 )):GAUGE:%"
    echo "gpu.mem=$(( (RANDOM % 1000) + 4000 )):GAUGE:MB"
    echo "ENDPANE"
fi
